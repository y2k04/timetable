Before you start using this application, there are some steps you need to follow to ensure that the application works.

Requirements:
Windows Vista and above
A timetable (as a .PNG)


Instructions:
1. Copy and paste your timetable to the directory where "Timetable.exe" is located and rename it to "timetable.png".
2. Open "startup.cmd".
3. If you want to, drag "Timetable.exe" to your taskbar.
4. You may run the program at this point, and whenever you turn your computer on, it will open as soon as you login.